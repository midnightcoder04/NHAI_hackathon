"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const db_1 = require("./db");
const PersonnelProcessor_1 = require("./processors/PersonnelProcessor");
const VerificationProcessor_1 = require("./processors/VerificationProcessor");
const FaceImageProcessor_1 = require("./processors/FaceImageProcessor");
const WebhookNotifier_1 = require("./processors/WebhookNotifier");
// ---------------------------------------------------------------------------
// AWS clients (lazy-initialised, re-used across warm invocations)
// ---------------------------------------------------------------------------
const sqs = new client_sqs_1.SQSClient({ region: process.env.AWS_REGION ?? 'ap-south-1' });
const s3 = new client_s3_1.S3Client({ region: process.env.AWS_REGION ?? 'ap-south-1' });
const QUEUE_URL = process.env.SQS_QUEUE_URL ?? '';
const BUCKET = process.env.FACE_IMAGES_BUCKET ?? '';
const PRESIGN_EXPIRY_SECONDS = 15 * 60; // 15 minutes
// ---------------------------------------------------------------------------
// Validation helpers
// ---------------------------------------------------------------------------
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function validateBatchBody(body) {
    const errors = [];
    if (!body || typeof body !== 'object') {
        return { valid: false, errors: [{ field: 'body', issue: 'must be a JSON object' }] };
    }
    const b = body;
    if (typeof b['deviceId'] !== 'string' || !UUID_RE.test(b['deviceId'])) {
        errors.push({ field: 'deviceId', issue: 'must be a UUID' });
    }
    if (typeof b['batchId'] !== 'string' || !UUID_RE.test(b['batchId'])) {
        errors.push({ field: 'batchId', issue: 'must be a UUID' });
    }
    if (typeof b['sentAt'] !== 'string' || isNaN(Date.parse(b['sentAt']))) {
        errors.push({ field: 'sentAt', issue: 'must be an ISO-8601 date string' });
    }
    const personnel = Array.isArray(b['personnel']) ? b['personnel'] : [];
    const verificationRecords = Array.isArray(b['verificationRecords'])
        ? b['verificationRecords']
        : [];
    const faceImages = Array.isArray(b['faceImages']) ? b['faceImages'] : [];
    if (personnel.length > 100) {
        errors.push({ field: 'personnel', issue: 'max 100 records per batch' });
    }
    if (verificationRecords.length > 500) {
        errors.push({ field: 'verificationRecords', issue: 'max 500 records per batch' });
    }
    if (faceImages.length > 200) {
        errors.push({ field: 'faceImages', issue: 'max 200 records per batch' });
    }
    // All faceImages must have s3Key populated
    for (let i = 0; i < faceImages.length; i++) {
        const fi = faceImages[i];
        if (!fi['s3Key'] || typeof fi['s3Key'] !== 'string' || fi['s3Key'] === '') {
            errors.push({
                field: `faceImages[${i}].s3Key`,
                issue: 'must be populated (upload image before submitting metadata)',
            });
        }
    }
    if (errors.length > 0)
        return { valid: false, errors };
    return {
        valid: true,
        errors: [],
        parsed: {
            deviceId: b['deviceId'],
            batchId: b['batchId'],
            sentAt: b['sentAt'],
            personnel,
            verificationRecords,
            faceImages,
        },
    };
}
// ---------------------------------------------------------------------------
// HTTP handler — POST /sync/batch
// ---------------------------------------------------------------------------
async function handleSyncBatch(event) {
    let rawBody;
    try {
        rawBody = JSON.parse(event.body ?? '{}');
    }
    catch {
        return {
            statusCode: 400,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                error: 'VALIDATION_ERROR',
                message: 'Request body is not valid JSON',
                details: [],
            }),
        };
    }
    const { valid, errors, parsed } = validateBatchBody(rawBody);
    if (!valid || !parsed) {
        return {
            statusCode: 400,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                error: 'VALIDATION_ERROR',
                message: 'Request validation failed',
                details: errors,
            }),
        };
    }
    // Enqueue to SQS FIFO
    let sqsResult;
    try {
        sqsResult = await sqs.send(new client_sqs_1.SendMessageCommand({
            QueueUrl: QUEUE_URL,
            MessageBody: JSON.stringify(rawBody),
            MessageGroupId: parsed.deviceId,
            MessageDeduplicationId: parsed.batchId,
        }));
    }
    catch (err) {
        const e = err;
        // FIFO deduplication: SQS rejects a duplicate MessageDeduplicationId within
        // the 5-minute deduplication window.
        if (e.name === 'MessageAlreadyInflight' || e.name === 'AWS.SimpleQueueService.NonExistentQueue') {
            return {
                statusCode: 409,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    error: 'DUPLICATE_BATCH',
                    batchId: parsed.batchId,
                    message: 'Batch already processed',
                }),
            };
        }
        console.error('[handler] SQS SendMessage error:', err);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: 'INTERNAL_ERROR', message: 'Failed to enqueue batch' }),
        };
    }
    const receivedAt = new Date().toISOString();
    return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            batchId: parsed.batchId,
            receivedAt,
            queueMessageId: sqsResult.MessageId ?? '',
            accepted: {
                personnel: (parsed.personnel ?? []).length,
                verificationRecords: (parsed.verificationRecords ?? []).length,
                faceImages: (parsed.faceImages ?? []).length,
            },
        }),
    };
}
async function handlePresign(event) {
    let body;
    try {
        body = JSON.parse(event.body ?? '{}');
    }
    catch {
        return {
            statusCode: 400,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: 'VALIDATION_ERROR', message: 'Invalid JSON body' }),
        };
    }
    if (!body.deviceId || !Array.isArray(body.images)) {
        return {
            statusCode: 400,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                error: 'VALIDATION_ERROR',
                message: 'deviceId and images[] are required',
            }),
        };
    }
    const expiresAt = new Date(Date.now() + PRESIGN_EXPIRY_SECONDS * 1000).toISOString();
    const presignedUrls = await Promise.all(body.images.map(async (img) => {
        const s3Key = `images/${body.deviceId}/${img.faceImageId}.jpg`;
        const uploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(s3, new client_s3_1.PutObjectCommand({
            Bucket: BUCKET,
            Key: s3Key,
            ContentType: img.contentType ?? 'image/jpeg',
            ContentLength: img.contentLength,
        }), { expiresIn: PRESIGN_EXPIRY_SECONDS });
        return { faceImageId: img.faceImageId, s3Key, uploadUrl, expiresAt };
    }));
    return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ presignedUrls }),
    };
}
// ---------------------------------------------------------------------------
// SQS event handler — processes one message per invocation
// ---------------------------------------------------------------------------
async function handleSQSEvent(event) {
    const batchItemFailures = [];
    for (const record of event.Records) {
        let body;
        try {
            body = JSON.parse(record.body);
        }
        catch (err) {
            console.error('[handler] Failed to parse SQS message body:', err);
            batchItemFailures.push({ itemIdentifier: record.messageId });
            continue;
        }
        const pool = (0, db_1.getPool)();
        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            const personnelCount = await (0, PersonnelProcessor_1.processPersonnel)((body.personnel ?? []), client, body.deviceId);
            const verificationsCount = await (0, VerificationProcessor_1.processVerifications)((body.verificationRecords ?? []), client);
            const imagesCount = await (0, FaceImageProcessor_1.processFaceImages)((body.faceImages ?? []), client, body.deviceId);
            // Audit log
            await client.query(`INSERT INTO sync_job_log
           (batch_id, device_id, received_at, processed_at, status,
            personnel_upserted, verifications_inserted, images_registered)
         VALUES ($1, $2, NOW(), NOW(), 'completed', $3, $4, $5)
         ON CONFLICT (batch_id) DO UPDATE SET
           processed_at = NOW(),
           status = 'completed',
           personnel_upserted = EXCLUDED.personnel_upserted,
           verifications_inserted = EXCLUDED.verifications_inserted,
           images_registered = EXCLUDED.images_registered`, [body.batchId, body.deviceId, personnelCount, verificationsCount, imagesCount]);
            await client.query('COMMIT');
            // Webhook notification (best-effort, non-fatal)
            await (0, WebhookNotifier_1.notifyWebhook)({
                batchId: body.batchId,
                deviceId: body.deviceId,
                processedAt: new Date().toISOString(),
                summary: {
                    personnelUpserted: personnelCount,
                    verificationsInserted: verificationsCount,
                    imagesRegistered: imagesCount,
                },
            });
            console.log(`[handler] batch ${body.batchId} processed: ` +
                `${personnelCount} personnel, ${verificationsCount} verifications, ${imagesCount} images`);
        }
        catch (err) {
            await client.query('ROLLBACK').catch(() => undefined);
            console.error(`[handler] Failed to process batch ${body.batchId}:`, err);
            batchItemFailures.push({ itemIdentifier: record.messageId });
        }
        finally {
            client.release();
        }
    }
    return { batchItemFailures };
}
// ---------------------------------------------------------------------------
// Lambda entry point — detects trigger type by event shape
// ---------------------------------------------------------------------------
async function handler(event) {
    // SQS events have Records[0].body (string) with no routeKey
    if ('Records' in event && Array.isArray(event.Records) && event.Records[0]?.body !== undefined) {
        return handleSQSEvent(event);
    }
    // API Gateway v2 events have routeKey
    const httpEvent = event;
    const routeKey = httpEvent.routeKey ?? '';
    if (routeKey === 'POST /sync/batch') {
        return handleSyncBatch(httpEvent);
    }
    if (routeKey === 'PUT /sync/images/presign') {
        return handlePresign(httpEvent);
    }
    return {
        statusCode: 404,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'NOT_FOUND', message: `Unknown route: ${routeKey}` }),
    };
}
